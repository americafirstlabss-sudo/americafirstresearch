# America First Labs Shopify Theme

This workspace now contains a custom Shopify theme scaffold designed around a premium research-lab storefront aesthetic inspired by the structure of high-converting peptide stores, while keeping the copy, styling, and brand expression original to America First Labs.

## Included

- Custom `theme.liquid` layout
- Homepage sections for hero, trust/value strip, featured collection, and support links
- Product, collection, cart, and contact templates
- Global CSS for the premium dark-and-gold visual system
- Theme editor settings for menus, copy, imagery, and featured collection wiring

## Next steps

1. Zip the theme files or upload this folder with Shopify CLI/theme tools.
2. In Shopify admin, assign your main navigation and footer menus.
3. Connect the homepage featured collection.
4. Upload your logo and hero image.
5. Replace placeholder compliance/disclaimer language with your final legal copy.

## Important

This is a front-end theme scaffold only. Product data, policies, menus, collections, and checkout settings still need to be configured inside Shopify.
